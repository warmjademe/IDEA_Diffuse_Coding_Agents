"""Apply the same confidence rule to the two overlapping missing-Flash cases."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sys

from confidence_review import INSTRUCTIONS, parse_confidence


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    root, out = Path(args.root), Path(args.out)
    sys.path.insert(0, str(root/'code'))
    from api import Runner, digest, dump
    import prompts
    audit = json.loads((root/'machine_review/formal/results.json').read_text())
    selected = [f for f in audit['disagreements_or_unknown'] if f['flash_y'] is None
                and None not in f['pro_y'] and f['pro_y'][0] != f['pro_y'][1]]
    assert len(selected) == 2
    annotations = {(a['key'], a['pass']): a for a in audit['annotations']}
    tasks = {t['task_id']: t for language in ('python', 'java')
             for t in json.loads((root/f'data/{language}_formal.json').read_text())['tasks']}
    jobs = []
    for f in selected:
        key = f['key']
        record = json.loads((root/'runs/records'/(digest(key)+'.json')).read_text())
        order = [1, 2] if int(digest(['confidence_order_20260924', key])[:8], 16) % 2 == 0 else [2, 1]
        body = json.loads(prompts.reference(tasks[record['task_id']], record['review'])[1]['content'])
        body.update(candidate_a=annotations[key, order[0]]['label'], candidate_b=annotations[key, order[1]]['label'])
        jobs.append({'key': key, 'candidate_order': order,
                     'messages': [{'role': 'system', 'content': INSTRUCTIONS},
                                  {'role': 'user', 'content': json.dumps(body, ensure_ascii=False)}]})
    plan = {'scope': 'Two cases counted originally as Flash missing also have disagreeing original Pro passes; same user-authorized confidence rule.',
            'logical_calls': 2, 'max_attempts': 4, 'jobs': jobs,
            'confidence_type': 'post_hoc_model_self_assessment_not_calibrated', 'tie_rule': 'unresolved'}
    path = out/'extra_plan.json'
    if path.exists():
        assert json.loads(path.read_text()) == plan
    else:
        dump(path, plan)
    runner = Runner(root)

    def one(job):
        target = out/'extra_records'/(digest(job['key'])+'.json')
        if target.exists():
            return json.loads(target.read_text())
        for attempt in range(2):
            call = runner.call('supplement/20260924_confidence_overlap/'+job['key'], 'formal', 'official_pro',
                               job['messages'], max_tokens=8192, temperature=0, parser=parse_confidence, attempt=attempt)
            if call['status'] == 'ok':
                break
        result = {'key': job['key'], 'call_id': call['id'], 'status': call['status'],
                  'candidate_order': job['candidate_order'], 'confidence_assessment': call.get('parsed'),
                  'selected_original_pro_pass': None, 'selected_label': None,
                  'confidence_type': 'new_post_hoc_model_self_assessment', 'calibrated': False}
        if call['status'] == 'ok':
            a, b = (call['parsed'][name]['confidence'] for name in ('candidate_a', 'candidate_b'))
            if a != b:
                chosen = job['candidate_order'][0 if a > b else 1]
                result.update(selected_original_pro_pass=chosen, selected_label=annotations[job['key'], chosen]['label'],
                              selected_confidence=max(a, b), confidence_margin=abs(a-b))
        dump(target, result)
        return result

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(one, jobs))
    summary = {'processed': len(results), 'selected': sum(r['selected_label'] is not None for r in results),
               'confidence_is_calibrated': False, 'human_labels_created': 0}
    dump(out/'extra_results.json', {'summary': summary, 'records': results})
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
