"""Verify user-directed label choices and label the recomputed analysis clearly."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    root, out = Path(args.root), Path(args.out)
    sys.path.insert(0, str(root/'code'))
    from api import digest, dump
    plan = json.loads((out/'plan.json').read_text())
    for path, expected in plan['protected_sha256'].items():
        assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected, path
    view = out/'analysis_view_adopted_pro'
    policy = json.loads((out/'pro_priority_policy.json').read_text())
    selected = policy['adopted_binary_labels']
    assert len(selected) == 36
    for key, decision in selected.items():
        rec = json.loads((view/'runs/records'/(digest(key)+'.json')).read_text())
        assert rec['reference']['y'] == decision['y']
        if decision['source'] == 'two_original_official_pro_passes_agree':
            assert all(p['y'] == decision['y'] for p in decision['pass_labels'])
        else:
            call = json.loads((root/'runs/raw'/(decision['confidence_assessment_call_id']+'.json')).read_text())
            a, b = (call['parsed'][k]['confidence'] for k in ('candidate_a', 'candidate_b'))
            assert a != b
            winner = 'candidate_a' if a > b else 'candidate_b'
            body = json.loads(call['request']['messages'][1]['content'])
            assert body[winner]['y'] == decision['y']
            assert max(a, b) == decision['confidence']
    overview = json.loads((out/'audit_200_supplementary_view.json').read_text())
    stats = json.loads((view/'analysis/results.json').read_text())
    assert stats['formal_call_processing_complete']
    assert stats['official_pro_audit']['status'] == 'complete'
    assert all(stats['official_pro_audit']['results'][f'pass_{i}']['parsed'] == 200 for i in (1, 2))
    assert stats['human']['independent_human_reviewers'] == 0
    stats['supplement_provenance'] = {
        'type': 'post_experiment_user_authorized_label_corrections',
        'original_analysis_preserved': str(root/'analysis/results.json'),
        'technical_repairs': {'restored_original_reviews': 2, 'filled_reference_labels': 9, 'filled_checker_scores': 3, 'filled_pro_audit_slots': 4},
        'adopted_reference_sources': {'original_two_pro_passes_agree': 11, 'higher_post_hoc_pro_confidence': 25},
        'confidence_is_calibrated': False, 'thresholds_prompts_and_dataset_membership_unchanged': True,
        'human_author_check': 'pending'}
    stats['automatic_reference']['label_source'] = 'Original Flash with separately recorded technical repairs and user-authorized Pro label adoption.'
    stats['official_pro_audit']['note'] = 'Two original requests to the same official Pro model, with missing slots restored; not independent human reviewers. User-authorized agreeing-Pro and confidence-based label corrections are documented in supplement_provenance. Original results retained; no threshold or prompt retuning.'
    dump(view/'analysis/results.json', stats)
    original = {k: (json.loads(p.read_text()).get('reference') or {}).get('y')
                for p in (root/'runs/records').glob('*.json') for k in [json.loads(p.read_text())['key']]}
    changes = []
    for p in (view/'runs/records').glob('*.json'):
        rec = json.loads(p.read_text())
        y = (rec.get('reference') or {}).get('y')
        if original[rec['key']] != y:
            changes.append({'key': rec['key'], 'before': original[rec['key']], 'after': y})
    assert len(changes) == 30
    with sqlite3.connect(root/'runs/ledger.sqlite') as db:
        db.row_factory = sqlite3.Row
        calls = [dict(r) for r in db.execute("SELECT role,status,count(*) AS n,sum(estimated_usd) AS estimated_usd FROM calls WHERE logical_id LIKE 'supplement/20260924_%' GROUP BY role,status")]
    report = {'status': 'supplement_and_recomputed_statistics_complete_author_check_pending',
              'audit_coverage': overview['summary'], 'changed_existing_binary_labels': sum(c['before'] in (0, 1) for c in changes),
              'newly_filled_binary_labels': sum(c['before'] is None for c in changes),
              'primary_hashes_verified': len(plan['protected_sha256']),
              'user_rule_decisions_independently_verified': len(selected), 'calls': calls,
              'human_labels_created': 0, 'statistical_analysis_recomputed': True}
    dump(out/'completion_verification.json', report)
    dump(out/'binary_label_changes.json', changes)
    dump(root/'runs/supplement_status_20260924.json', {**report, 'results_directory': str(out),
         'adopted_analysis': str(view/'analysis/results.json'), 'primary_pipeline_state_unchanged': True})
    text = '''# 43 条记录的补充核查结果（2026-09-24）

这 43 条来自预先抽取的 200 份复核评审，不是 43 个缺陷无法复现，也不是 43 次程序停机。最初按优先原因归为：23 条 Pro 自身判断不一致、11 条 Pro 两次一致但与 Flash 不同、7 条 Flash 标签缺失、2 条评审格式未被接受。7 条标签缺失中有 2 条同时存在 Pro 自身分歧，因此 Pro 自身分歧合计 25 条；它们不是新增样本。

| 类别 | 已完成的处理 |
|---|---|
| 11 条两次 Pro 一致 | 按用户指示采用原来两次一致的 Pro 二分类标签，保留两份完整理由 |
| 23 条 Pro 自身分歧 | 补做基于原始证据的候选结论置信度评估，采用评分较高的原 Pro 结论 |
| 7 条 Flash 标签缺失 | 原因均为原有 8192 输出额度耗尽；在独立补充批次中提高至 16384，补齐标签，其中 2 条 Pro 分歧同样按置信度处理 |
| 2 条评审格式未被接受 | 原文本实际存在，分别采用代码注释编号和嵌套 JSON；原字节完整恢复，补齐参考标签、Pro 两轮复核和检查器评分，无需重新生成攻击 |

23 条完整标签下的 Pro 分歧中，21 条涉及 M（是否有实质性误导）的不同判断，部分还涉及 C/A。分歧不能简单归结为接口错误。

补充后，200 份抽样评审全部可用，参考标签达到 200/200，原定两轮 Pro 复核达到 400/400。第三轮盲复核覆盖原来的 43 条，作为诊断材料保存；采用标签时遵循用户随后指定的一致-Pro/较高置信度规则，而不是自动以第三轮多数票替代。

原接口没有返回可比较的置信度。25 条置信度选择使用统一的新复核提示，提供原始代码、补丁、测试日志、评审和两份候选结论；不提供 Flash 标签、检查器得分、攻击意图或第三轮结论，候选次序由固定规则交叉安排。所选置信度分数为 75–95，无同分项。这些分数是模型本轮自评，不是原调用的概率或经校准正确率。

共有 36 条采用 Pro 来源的标签，其中 11 条采用两次一致结果、25 条采用置信度较高结果。与原始二分类标签相比，21 条已有标签发生变化，另补齐 9 条缺失标签。其余采用 Pro 的条目与原 Flash 标签相同。机器意见原本的分歧仍完整保留；“采用一个标签”不表示历史输出变得一致。

已使用冻结的统计程序重新计算全套结果。数据集成员、阈值、提示词和旧结果均保留；补充后的统计在独立目录，明确标注为实验后标签校正。置信度选择和技术恢复都属于补充处理，写入论文时需报告规则，并同时展示原始标签下的敏感性结果。没有把任何机器评价填写为人工标注，作者校对仍待实际完成。

材料：

- `analysis_view_adopted_pro/analysis/results.json`：补充与采用规则后的完整统计。
- `completion_verification.json`：原始证据哈希、规则执行和统计覆盖检查。
- `pro_priority_policy.json`：逐条采用标签及其依据。
- `priority_43_findings.md`：原始、第三轮和置信度评价的逐条理由。
- `author_review/review_packet_200.html`：可直接在浏览器打开的代码、补丁、测试和评审材料。
- `author_review/author_labels_template_200.json`：未预填机器结论的人工校对模板。

主实验原始结果仍在上级实验根目录的 `analysis/results.json`；补充后结果不会覆盖它。
'''
    (out/'supplement_report_20260924.md').write_text(text)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
