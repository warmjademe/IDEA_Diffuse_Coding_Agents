"""Bounded post-experiment audit repair, preserving all primary evidence."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import faulthandler
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import sys
import time

PREFIX = 'supplement/20260924_audit_gaps/'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def notify(message):
    address = os.environ.get('NOTIFY_SOCKET')
    if address:
        address = '\0'+address[1:] if address.startswith('@') else address
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
            sock.sendto(message.encode(), address)


def restore_verbatim(record):
    """Accept only the two diagnosed wrappers; change no source bytes."""
    raw = record['raw_generation_text']
    markers = re.findall(r'(?m)^# Comment (\d+)\s*$', raw)
    if markers:
        assert markers == list(map(str, range(1, 9)))
        return raw, 'eight_hash_comment_markers_original_bytes'
    from api import parse_json
    obj = parse_json(raw)
    assert set(obj) == {'review_fixture'}
    comments = obj['review_fixture']['comments']
    assert len(comments) == 8 and [c['id'] for c in comments] == list(range(1, 9))
    assert all(isinstance(c['text'], str) and c['text'].strip() for c in comments)
    return raw, 'nested_review_fixture_original_bytes'


def category(flag):
    if None in flag['pro_y']:
        return 'source_review_format_rejected'
    if flag['flash_y'] is None:
        return 'flash_output_truncated'
    return 'pro_self_disagreement' if len(set(flag['pro_y'])) > 1 else 'flash_vs_both_pro'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    root, out = Path(args.root), Path(args.out)
    sys.path.insert(0, str(root/'code'))
    from api import Runner, digest, dump, parse_reference, parse_score
    from machine_review import review_messages
    import prompts
    out.mkdir(parents=True, exist_ok=True)
    lock = (out/'execution.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    audit = json.loads((root/'machine_review/formal/results.json').read_text())
    flags = audit['disagreements_or_unknown']
    assert len(flags) == 43
    records = {x['key']: json.loads((root/'runs/records'/(digest(x['key'])+'.json')).read_text()) for x in flags}
    annotations = {(x['key'], x['pass']): x for x in audit['annotations']}
    jobs = {x['key']: x for x in json.loads((root/'protocol/formal_jobs.json').read_text())}
    tasks = {t['task_id']: t for lang in ('python', 'java')
             for t in json.loads((root/f'data/{lang}_formal.json').read_text())['tasks']}
    protected = list((root/'runs/records').glob('*.json')) + list((root/'code').glob('*.py'))
    protected += [p for p in (root/'protocol').glob('*.json') if p.name != 'pricing_snapshot.json']
    protected += [root/'machine_review/formal/results.json', root/'analysis/results.json',
                  root/'author_review/formal/author_labels_template.json']
    protected_hashes = {str(p.relative_to(root)): sha(p) for p in sorted(protected)}
    plan = {'kind': 'post_experiment_supplement_not_primary_results',
            'authorization': 'User requested explanation and supplementary experiments for the 43 flagged audit records on 2026-09-24.',
            'scope': 'Restore two original review texts verbatim; fill nine missing Flash references, four missing Pro slots and three checker scores; add exactly one blinded Pro pass to each of the original 43 flagged reviews.',
            'categories': dict(Counter(category(f) for f in flags)), 'flags': flags,
            'max_new_api_attempts': 118, 'attempts_per_logical_request': 2,
            'logical_requests': 59, 'workers': 6,
            'flash_output_budget': 16384, 'original_flash_output_budget': 8192,
            'other_parameters': 'Original prompts, model pins, temperatures and provider settings retained. Third Pro pass sees no previous labels, checker scores or selection reason.',
            'stopping': 'First protocol-valid response, at most two identical attempts; valid unknown labels are not retried to force agreement.',
            'interpretation': 'Targeted diagnostic sample; a 2-of-3 Pro vote is a machine consensus, not a human or gold label. Original results, missingness and disagreements remain reportable.',
            'protected_sha256': protected_hashes, 'source_sha256': sha(Path(__file__))}
    plan_path = out/'plan.json'
    if args.prepare:
        if plan_path.exists():
            assert json.loads(plan_path.read_text()) == plan
        else:
            dump(plan_path, plan)
        restorations = []
        for f in flags:
            rec = records[f['key']]
            if not rec.get('review'):
                raw, method = restore_verbatim(rec)
                restorations.append({'key': f['key'], 'method': method,
                                     'same_bytes': raw == rec['raw_generation_text'],
                                     'sha256': hashlib.sha256(raw.encode()).hexdigest()})
        assert len(restorations) == 2
        dump(out/'format_recovery_preflight.json', restorations)
        print(json.dumps({'status': 'prepared_no_model_calls', 'categories': plan['categories'],
                          'restorations': restorations, 'max_new_attempts': 118}, ensure_ascii=False))
        return
    assert plan_path.exists() and json.loads(plan_path.read_text()) == plan, 'supplement inputs changed'
    faulthandler.enable()
    # The service owns this process group. A restart may reconcile only its own
    # interrupted attempts; primary calls are never reset or retried here.
    runner = Runner(root)
    with runner.db() as db:
        pending = [dict(row) for row in db.execute("SELECT * FROM calls WHERE status='reserved'")]
    if pending:
        assert all(r['logical_id'].startswith(PREFIX) for r in pending)
        from watchdog import recover_interrupted
        incident = out/'recovery'/str(time.time_ns())
        incident.mkdir(parents=True)
        recover_interrupted(root, incident)
    notify('READY=1\nWATCHDOG=1\nSTATUS=Running bounded JSEP supplementary audit')

    def invoke(key, role, messages, tokens, parse):
        # Logical IDs differ from the original study and all costs remain in its
        # existing ledger. No original attempt counter is reset.
        for attempt in range(2):
            result = runner.call(PREFIX+key, 'formal', role, messages, max_tokens=tokens,
                                 temperature=0, parser=parse, attempt=attempt)
            if result['status'] == 'ok':
                return result
        return result

    def label_result(call):
        return {'status': call['status'], 'call_id': call['id'], 'label': call.get('parsed'),
                'returned_model': call.get('raw_response', {}).get('model')}

    def one(flag):
        key = flag['key']
        output = out/'records'/(digest(key)+'.json')
        if output.exists():
            return json.loads(output.read_text())
        rec, job = records[key], jobs[key]
        task = tasks[rec['task_id']]
        review = rec.get('review')
        result = {'key': key, 'original_category': category(flag), 'original_flag': flag,
                  'annotator_type': 'model', 'post_hoc_diagnostic': True,
                  'original_record_sha256': protected_hashes['runs/records/'+digest(key)+'.json'],
                  'original_reference': rec.get('reference'), 'recovered_review': None,
                  'supplement_reference': None, 'supplement_scores': {}}
        if not review:
            review, method = restore_verbatim(rec)
            result.update(recovered_review=review, recovery_method=method,
                          recovered_review_sha256=hashlib.sha256(review.encode()).hexdigest())
        reference = rec.get('reference')
        if not reference:
            call = invoke(key+'/flash_reference_16384', 'reference', prompts.reference(task, review), 16384, parse_reference)
            result['supplement_reference'] = label_result(call)
            reference = call.get('parsed') if call['status'] == 'ok' else None
        result['effective_flash_y'] = (reference or {}).get('y')
        if not rec.get('review'):
            for condition in job['scores']:
                role, defense, *run = condition.split('/')
                assert defense != 'D4', 'unexpected missing D4 review in locked plan'
                call = invoke(key+'/'+condition, role, prompts.checker(task, review, defense, prompts.RUBRIC), 2048, parse_score)
                result['supplement_scores'][condition] = {'status': call['status'], 'call_id': call['id'],
                                                         'score': (call.get('parsed') or {}).get('score')}
        pros = []
        for rep in (1, 2):
            old = annotations[key, rep]
            if old['status'] == 'ok':
                pros.append({**old, 'source': 'original'})
            else:
                assert old['status'] == 'review_unavailable'
                call = invoke(key+f'/pro_missing_pass{rep}', 'official_pro', review_messages(task, review), 8192, parse_reference)
                pros.append({**label_result(call), 'pass': rep, 'source': 'supplement'})
        call = invoke(key+'/pro_blind_pass3', 'official_pro', review_messages(task, review), 8192, parse_reference)
        pros.append({**label_result(call), 'pass': 3, 'source': 'supplement_blinded_diagnostic'})
        ys = [(p.get('label') or {}).get('y') for p in pros]
        result.update(pro_passes=pros, pro_y=ys,
                      pro_machine_majority_y=(int(sum(ys) >= 2) if all(y in (0, 1) for y in ys) else None),
                      pro_unanimous=len(set(ys)) == 1 and ys[0] in (0, 1), finished=time.time())
        dump(output, result)
        return result

    results = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(one, flag) for flag in flags]
        for future in as_completed(futures):
            results.append(future.result())
            dump(out/'progress.json', {'processed': len(results), 'planned': len(flags), 'updated': time.time()})
            notify('WATCHDOG=1\nSTATUS=Completed '+str(len(results))+'/43 supplementary audit items')
    results.sort(key=lambda r: r['key'])
    assert all(sha(root/p) == value for p, value in protected_hashes.items()), 'primary evidence was modified'
    with runner.db() as db:
        calls = [dict(r) for r in db.execute('SELECT status,count(*) AS n,sum(estimated_usd) AS estimated_usd FROM calls WHERE logical_id LIKE ? GROUP BY status', (PREFIX+'%',))]
    assert sum(r['n'] for r in calls) <= 118
    summary = {'status': 'supplement_processed_author_check_pending', 'finished': time.time(),
               'finished_local': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
               'flagged_items_processed': len(results), 'original_categories': plan['categories'],
               'source_reviews_restored_verbatim': sum(r['recovered_review'] is not None for r in results),
               'flash_references_filled': sum(bool(r['supplement_reference']) and r['effective_flash_y'] in (0, 1) for r in results),
               'supplement_checker_scores_valid': sum(s['score'] is not None for r in results for s in r['supplement_scores'].values()),
               'missing_pro_slots_filled': sum(p['source'] == 'supplement' and (p.get('label') or {}).get('y') in (0, 1) for r in results for p in r['pro_passes']),
               'third_pro_passes_valid': sum((r['pro_passes'][2].get('label') or {}).get('y') in (0, 1) for r in results),
               'machine_majority_available': sum(r['pro_machine_majority_y'] in (0, 1) for r in results),
               'three_pro_passes_unanimous': sum(r['pro_unanimous'] for r in results),
               'flash_vs_machine_majority_differences': sum(r['effective_flash_y'] in (0, 1) and r['pro_machine_majority_y'] in (0, 1) and r['effective_flash_y'] != r['pro_machine_majority_y'] for r in results),
               'primary_evidence_hashes_unchanged': True, 'calls': calls,
               'note': 'Machine consensus is diagnostic only; original primary estimates and disagreements remain unchanged. Author review still pending.'}
    dump(out/'results.json', {'summary': summary, 'records': results})
    dump(out/'summary.json', summary)
    notify('STATUS=Supplement completed; primary evidence retained; author review pending')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
