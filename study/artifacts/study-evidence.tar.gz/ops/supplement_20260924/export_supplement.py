"""Export supplement provenance, complete author packet, and model disagreements."""
import argparse
from collections import Counter
import copy
import hashlib
import html
import json
from pathlib import Path
import shutil
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    root, out = Path(args.root), Path(args.out)
    sys.path.insert(0, str(root/'code'))
    from api import dump, digest
    supplement = json.loads((out/'results.json').read_text())
    items = {r['key']: r for r in supplement['records']}
    audit = json.loads((root/'machine_review/formal/results.json').read_text())
    baseline = {(a['key'], a['pass']): a for a in audit['annotations']}
    sample = json.loads((root/'protocol/human_sampling.json').read_text())['selected']
    tasks = {t['task_id']: t for language in ('python', 'java')
             for t in json.loads((root/f'data/{language}_formal.json').read_text())['tasks']}
    forms = copy.deepcopy(json.loads((root/'author_review/formal/author_labels_template.json').read_text()))
    mapping = json.loads((root/'human/formal/private_mapping.json').read_text())
    blindmap = {m['key']: m['blind_id'] for m in mapping}
    adopted = {}
    for key, item in items.items():
        if item['original_category'] == 'flash_vs_both_pro':
            a, b = (baseline[key, rep]['label']['y'] for rep in (1, 2))
            assert a == b and a in (0, 1)
            adopted[key] = {'y': a, 'source': 'two_original_official_pro_passes_agree',
                            'original_flash_y': item['original_flag']['flash_y'],
                            'pass_labels': [baseline[key, rep]['label'] for rep in (1, 2)],
                            'user_authorized_after_experiment': True}
    assert len(adopted) == 11
    confidence_data = json.loads((out/'confidence/results.json').read_text())
    confidence_items = {r['key']: r for r in confidence_data['records']}
    extra = out/'confidence/extra_results.json'
    if extra.exists():
        confidence_items.update({r['key']: r for r in json.loads(extra.read_text())['records']})
    for key, result in confidence_items.items():
        if result['selected_label'] is None:
            continue
        assert key not in adopted
        adopted[key] = {**result['selected_label'],
            'source': 'official_pro_higher_post_hoc_confidence',
            'selected_original_pro_pass': result['selected_original_pro_pass'],
            'confidence': result['selected_confidence'], 'confidence_is_calibrated': False,
            'confidence_assessment_call_id': result['call_id'],
            'original_flash_y': items[key]['original_flag']['flash_y'],
            'user_authorized_after_experiment': True}
    dump(out/'pro_priority_policy.json', {
        'authorization': ['2026-09-24: 11 条：Pro 两次判断一致，但与 Flash 的判断不同。以 pro 结果为准',
                          '2026-09-24: 23 条：同一个 Pro 模型的两次判断不一致。以置信度最高的结果为准'],
        'scope': '11 original agreeing-Pro cases plus originally disagreeing Pro cases with explicit confidence assessments; any added overlap with the missing-Flash category is listed individually.',
        'primary_evidence_overwritten': False, 'retuned_thresholds_or_prompts': False,
        'unknown_or_tied_confidence_cases': 'Retain unresolved; do not infer confidence from original assertive wording.',
        'adopted_binary_labels': adopted})
    labels, primary_slots = [], []
    for selected in sample:
        key = selected['key']
        rec = json.loads((root/'runs/records'/(digest(key)+'.json')).read_text())
        s = items.get(key, {})
        review = s.get('recovered_review') or rec.get('review')
        flash = s.get('effective_flash_y') if s else (rec.get('reference') or {}).get('y')
        pro = s.get('pro_passes') or [baseline[key, rep] for rep in (1, 2)]
        ys = [(p.get('label') or {}).get('y') for p in pro]
        if len(ys) == 3:
            vote = int(sum(ys) >= 2) if all(y in (0, 1) for y in ys) else None
        else:
            vote = ys[0] if ys[0] in (0, 1) and ys[0] == ys[1] else None
        labels.append({'key': key, 'inclusion_probability': selected['inclusion_probability'],
                       'flash_original_y': (rec.get('reference') or {}).get('y'),
                       'flash_with_supplement_y': flash, 'pro_y': ys,
                       'pro_machine_majority_y': vote, 'review_available': bool(review),
                       'original_flagged': key in items,
                       'adopted_y': adopted[key]['y'] if key in adopted else flash,
                       'adopted_source': adopted[key]['source'] if key in adopted else 'flash'})
        for rep, p in enumerate(pro[:2], 1):
            primary_slots.append({'key': key, 'pass': rep, 'label': p.get('label'),
                                  'call_id': p.get('call_id'), 'status': p['status'],
                                  'source': p.get('source', 'original')})
        if s.get('recovered_review'):
            blind = hashlib.sha256(('blind-v3:'+key+digest(review)).encode()).hexdigest()[:16]
            assert key not in blindmap
            blindmap[key] = blind
            task = tasks[rec['task_id']]
            forms['records'].append({'blind_id': blind, 'code': task['code_context'],
                'reference_fix': task['gold_patch'], 'test_patch': task.get('test_patch', ''),
                'failure_log': task['failure_log'], 'review': review,
                'C': None, 'A': None, 'M': None, 'evidence': '', 'checked': False})
            mapping.append({'blind_id': blind, 'key': key, 'task_id': rec['task_id'],
                            'inclusion_probability': selected['inclusion_probability']})
    summary = {'selected_reviews': len(sample), 'available_reviews': sum(r['review_available'] for r in labels),
               'known_flash_labels_before': sum(r['flash_original_y'] in (0, 1) for r in labels),
               'known_flash_labels_after': sum(r['flash_with_supplement_y'] in (0, 1) for r in labels),
               'valid_pro_primary_slots_after': sum((r.get('label') or {}).get('y') in (0, 1) for r in primary_slots),
               'machine_majority_available': sum(r['pro_machine_majority_y'] in (0, 1) for r in labels),
               'flash_vs_pro_majority_differences': sum(r['flash_with_supplement_y'] in (0, 1) and
                   r['pro_machine_majority_y'] in (0, 1) and r['flash_with_supplement_y'] != r['pro_machine_majority_y'] for r in labels),
               'original_43_flags_retained': True, 'new_human_annotations_created': 0,
               'user_adopted_pro_labels': len(adopted),
               'adopted_pro_sources': dict(Counter(a['source'] for a in adopted.values())),
               'note': 'Supplementary view only. A model majority is not gold truth; labels and primary statistics were not overwritten.'}
    dump(out/'audit_200_supplementary_view.json', {'summary': summary, 'labels': labels, 'pro_primary_slots': primary_slots})
    author = out/'author_review'
    target = author/'author_labels_template_200.json'
    assert len(forms['records']) == len({x['blind_id'] for x in forms['records']}) == 200
    assert all(x.get('checked') is False and all(x[d] is None for d in ('C', 'A', 'M')) for x in forms['records'])
    if target.exists():
        assert json.loads(target.read_text()) == forms, 'do not overwrite annotations'
    else:
        dump(target, forms)
    dump(author/'private_mapping_200.json', mapping)
    dump(author/'priority_43.json', [{'blind_id': blindmap[k], 'key': k, 'category': r['original_category']}
                                   for k, r in items.items()])
    category_names = {'pro_self_disagreement': 'Pro 两次判断不一致', 'flash_vs_both_pro': 'Flash 与两次 Pro 判断不同',
                      'flash_output_truncated': 'Flash 输出截断', 'source_review_format_rejected': '原始评审格式未被接受'}
    lines = ['# 43 条记录的补充核查', '',
             '原始分歧记录全部保留。第三轮 Pro 是不展示旧标签的机器复核，多数票供作者定位分歧，不是人工标签。', '']
    for index, (key, r) in enumerate(items.items(), 1):
        lines += [f'## {index}. {blindmap[key]}', '', f'- 来源：`{key}`',
                  f'- 原因：{category_names[r["original_category"]]}',
                  f'- Flash 原标签：{r["original_flag"]["flash_y"]}；补充后标签：{r["effective_flash_y"]}',
                  f'- Pro 三次标签：{r["pro_y"]}；机器多数票：{r["pro_machine_majority_y"]}',
                  (f'- 采用结果：{adopted[key]["y"]}；依据：{adopted[key]["source"]}。' if key in adopted else '- 状态：第三轮机器意见作为核查材料，未自动替换已知标签。'), '']
        if key in confidence_items:
            c = confidence_items[key]
            lines += [f'- 置信度复核：选用原 Pro 第 {c["selected_original_pro_pass"]} 次；置信度 {c.get("selected_confidence")}；这不是经校准正确率。', '',
                      json.dumps(c['confidence_assessment'], ensure_ascii=False, indent=2), '']
        for p in r['pro_passes']:
            label = p.get('label') or {}
            lines += [f'Pro 第 {p["pass"]} 次：C={label.get("C")}，A={label.get("A")}，M={label.get("M")}', '',
                      str(label.get('evidence', '未获得有效依据')), '']
    (out/'priority_43_findings.md').write_text('\n'.join(lines)+'\n')
    # Offline browser-readable original evidence. Machine labels are omitted so
    # the author can make an initial judgment before opening the separate audit.
    priorities = {blindmap[k] for k in items}
    parts = ['<!doctype html><html lang="zh"><meta charset="utf-8"><title>JSEP 作者校对材料</title>',
             '<style>body{font:16px/1.6 system-ui;max-width:1100px;margin:2em auto;padding:0 1em}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f5f5;padding:1em;font:13px/1.5 monospace}summary{cursor:pointer;padding:.7em;border-bottom:1px solid #ddd}h1{font-size:1.5em}</style>',
             '<h1>JSEP：200 份评审的作者校对材料</h1><p>43 份重点条目排在前面。C：是否指出核心缺陷；A：是否正确定位并可操作；M：是否含实质性误导。请先阅读原始证据，实际校对后再填写 JSON 模板；本页面不预填机器结论。</p>']
    for f in sorted(forms['records'], key=lambda x: (x['blind_id'] not in priorities, x['blind_id'])):
        parts.append('<details id="'+f['blind_id']+'"><summary>'+('重点核查 · ' if f['blind_id'] in priorities else '')+f['blind_id']+'</summary>')
        for title, field in [('待评价评审', 'review'), ('缺陷代码', 'code'), ('参考修复', 'reference_fix'), ('测试修改', 'test_patch'), ('真实失败日志', 'failure_log')]:
            parts.append('<h3>'+title+'</h3><pre>'+html.escape(f[field])+'</pre>')
        parts.append('</details>')
    parts.append('</html>')
    (author/'review_packet_200.html').write_text('\n'.join(parts))
    (author/'README.md').write_text('先打开 review_packet_200.html 阅读证据；43 份重点条目排在前面。实际校对后填写 author_labels_template_200.json 中对应记录的 checked、C/A/M 和 evidence，另存 author_labels.json，并填写真实 reviewer_id、experience、consent、review_completed。保留未校对条目。机器原始意见另见 ../priority_43_findings.md。新增两份恢复文本使用本目录 private_mapping_200.json 映射，后续统计应使用此补充映射，不覆盖原始 198 条映射。\n')
    # A separate complete input view allows the frozen analysis program to
    # recompute results after technical repairs and the authorized Pro corrections.
    # All old records and statistical outputs remain intact at the primary root.
    view = out/'analysis_view_adopted_pro'
    if not view.exists():
        (view/'runs/records').mkdir(parents=True)
        shutil.copytree(root/'protocol', view/'protocol')
        (view/'data').mkdir()
        for language in ('python', 'java'):
            shutil.copy2(root/f'data/{language}_formal.json', view/f'data/{language}_formal.json')
        for p in (root/'runs/records').glob('*.json'):
            shutil.copy2(p, view/'runs/records'/p.name)
        shutil.copy2(root/'runs/formal_calls_finished.json', view/'runs/formal_calls_finished.json')
        for key, item in items.items():
            path = view/'runs/records'/(digest(key)+'.json')
            rec = json.loads(path.read_text())
            changed = False
            if item.get('recovered_review'):
                rec.update(review=item['recovered_review'], status='supplement_format_recovered',
                           original_status=rec['status'], supplement_recovery_method=item['recovery_method'])
                rec.setdefault('scores', {}).update(item['supplement_scores'])
                changed = True
            ref = item.get('supplement_reference')
            if ref and ref['status'] == 'ok':
                rec.update(reference=ref['label'], reference_call=ref['call_id'])
                changed = True
            if key in adopted:
                # Keep the original labels and confidence provenance instead
                # of inventing shared dimensions or original-call confidence.
                rec['reference'] = adopted[key]
                changed = True
            if changed:
                dump(path, rec)
        merged_audit = copy.deepcopy(audit)
        replacements = {(r['key'], r['pass']): r for r in primary_slots}
        for entry in merged_audit['annotations']:
            entry.update(replacements[entry['key'], entry['pass']])
        merged_audit['status'] = 'complete' if all(a['status'] == 'ok' for a in merged_audit['annotations']) else 'completed_with_missing'
        merged_audit['original_disagreements_or_unknown'] = merged_audit['disagreements_or_unknown']
        merged_audit['disagreements_or_unknown'] = [
            {'key': r['key'], 'flash_y': r['adopted_y'], 'pro_y': r['pro_y'][:2],
             'reference_source': r['adopted_source']} for r in labels
            if None in (r['adopted_y'], *r['pro_y'][:2]) or len(set((r['adopted_y'], *r['pro_y'][:2]))) > 1]
        merged_audit['source_records_sha256'] = digest([json.loads((view/'runs/records'/(digest(x['key'])+'.json')).read_text()) for x in sample])
        merged_audit['note'] += ' This is a post-experiment supplementary view; original audit and original disagreements are preserved separately.'
        dump(view/'machine_review/formal/results.json', merged_audit)
        dump(view/'analysis_provenance.json', {'primary_root': str(root), 'supplement_root': str(out),
            'interpretation': 'Post-experiment technical repair plus user-authorized agreeing-Pro/confidence-based label adoption. All primary results retained.',
            'corrected_binary_labels': len(adopted), 'supplement_summary': supplement['summary'],
            'original_records_hashes': json.loads((out/'plan.json').read_text())['protected_sha256']})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
