"""Local reading packet; model references never populate human annotations."""
import argparse
import hashlib
import html
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def esc(value):
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, indent=2)
    return html.escape(str(value if value is not None else '未提供'))


def outcome(value):
    return {0: '不合格（y=0）', 1: '合格（y=1）'}.get(value, '未确定')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', required=True)
    args = parser.parse_args()
    root = Path(args.evidence)
    folder = root/'author_review'
    template_path = folder/'author_labels_template_200.json'
    template_hash = hashlib.sha256(template_path.read_bytes()).hexdigest()
    forms = read(template_path)['records']
    mapping = {m['blind_id']: m for m in read(folder/'private_mapping_200.json')}
    priorities = {p['blind_id']: p for p in read(folder/'priority_43.json')}
    audit = read(root/'audit_200_supplementary_view.json')
    labels = {r['key']: r for r in audit['labels']}
    pro = {(a['key'], a['pass']): a for a in audit['pro_primary_slots']}
    supplement = {r['key']: r for r in read(root/'results.json')['records']}
    confidence = {r['key']: r for filename in ('results.json', 'extra_results.json')
                  for r in read(root/'confidence'/filename)['records']}
    categories = {'pro_self_disagreement': 'Pro 两次判断不一致',
                  'flash_vs_both_pro': 'Pro 两次一致，但与 Flash 不同',
                  'flash_output_truncated': 'Flash 标签缺失后补齐',
                  'source_review_format_rejected': '评审格式恢复后补齐评价'}
    sources = {'flash': 'Flash 参考标签（有缺失者已补齐）',
               'two_original_official_pro_passes_agree': '采用两次一致的 Pro 标签',
               'official_pro_higher_post_hoc_confidence': '采用补充置信度较高的 Pro 结论'}
    parts = ['''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JSEP 人工校对材料与大模型参考结果</title>
<style>
body{font:16px/1.65 system-ui,sans-serif;color:#17202a;max-width:1180px;margin:24px auto;padding:0 18px;background:#fafbfc}
h1{font-size:25px}h2{font-size:20px}h3{font-size:17px}p{margin:.7em 0}
.intro,.entry{background:white;border:1px solid #d9e0e8;border-radius:8px;padding:16px;margin:12px 0}
.tools{position:sticky;top:0;background:#f1f5f9;padding:12px;border-bottom:1px solid #c8d2df;z-index:1}
input[type=search]{font:inherit;width:min(480px,90%);padding:8px;margin-right:14px}
summary{cursor:pointer;font-weight:600;padding:8px 0;overflow-wrap:anywhere}
.badge{display:inline-block;border:1px solid #3c5d91;border-radius:4px;padding:0 6px;font-size:13px;color:#244777;margin-right:8px}
.muted{color:#556273;font-size:14px}.model{background:#f5f8fc;padding:12px;border-radius:6px;margin:12px 0}
pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f5f7;padding:12px;font:13px/1.55 ui-monospace,monospace}
table{border-collapse:collapse;width:100%;font-size:14px;margin:10px 0}th,td{text-align:left;border-bottom:1px solid #dce3ec;padding:8px;vertical-align:top}
.tablewrap{overflow-x:auto}a{color:#235b9c}details[hidden]{display:none}
</style></head><body>
<h1>人工校对材料与大模型参考结果</h1>
<div class="intro"><p>共 200 份评审：Python 120 份、Java 80 份。43 份重点记录排在前面。每条包含评审原文、缺陷代码、参考补丁、真实测试日志，以及 Pro 的结论和原始理由。</p>
<p><strong>人工判断三个问题：</strong>C：是否指出核心缺陷；A：是否正确定位或给出可操作的处理方向；M：是否存在实质性误导或捏造的缺陷指控。分别填 0、1 或 unknown，并写一句依据。C=1、A=1、M=0 时整体可接受；无法确定时保留 unknown。</p>
<p>建议先看原始证据，再展开模型参考。模型结论只是辅助材料；置信度是补充复核的模型自评，并非经校准正确率。人工填写模板保持空白，请只将实际检查过的条目标记 checked=true。</p>
<p><a href="author_labels_template_200.json" download>下载人工填写模板（JSON）</a> · <a href="../priority_43_findings.md">43 条原始模型意见对照</a></p></div>
<div class="tools"><input id="search" type="search" placeholder="搜索项目名、缺陷编号或校对编号"><label><input id="priorityOnly" type="checkbox"> 只看 43 条重点</label><div id="count" class="muted">显示 200 / 200 条</div></div>
''']
    for i, form in enumerate(sorted(forms, key=lambda f: (f['blind_id'] not in priorities, f['blind_id'])), 1):
        blind = form['blind_id']
        key = mapping[blind]['key']
        label = labels[key]
        priority = priorities.get(blind)
        source = key.split('/', 2)[2]
        language = 'Python' if '/python/' in key else 'Java'
        parts.append(f'<details class="entry" id="{blind}" data-priority="{int(bool(priority))}" data-search="{esc((blind+" "+key).lower())}">')
        parts.append(f'<summary>{i}. '+('<span class="badge">重点核查</span>' if priority else '')+f'{language} · {esc(source)}<br><span class="muted">校对编号：{blind}</span></summary>')
        if priority:
            parts.append('<p>重点原因：'+esc(categories[priority['category']])+'</p>')
        parts.append('<p class="muted">当前人工状态：未校对。请在模板中按此校对编号填写 C、A、M、evidence 和 checked。</p>')
        parts.append('<h3>待评价的评审原文</h3><pre>'+esc(form['review'])+'</pre>')
        for title, field in [('缺陷代码', 'code'), ('参考修复补丁', 'reference_fix'), ('测试修改', 'test_patch'), ('真实失败日志', 'failure_log')]:
            parts.append('<details><summary>'+title+'</summary><pre>'+esc(form[field])+'</pre></details>')
        parts.append('<details class="model"><summary>展开大语言模型参考结论与理由</summary>')
        parts.append('<p><strong>目前采用：'+outcome(label['adopted_y'])+'</strong>。依据：'+esc(sources[label['adopted_source']])+'。</p>')
        parts.append('<p>Flash 原标签：'+outcome(label['flash_original_y'])+'；补齐后：'+outcome(label['flash_with_supplement_y'])+'。</p>')
        rows = [(f'Pro 第 {rep} 次', pro[key, rep]['label']) for rep in (1, 2)]
        if key in supplement:
            rows.append(('Pro 第 3 次（补充盲复核）', supplement[key]['pro_passes'][2]['label']))
        parts.append('<div class="tablewrap"><table><thead><tr><th>评价轮次</th><th>C 识别缺陷</th><th>A 定位/可操作</th><th>M 实质误导</th><th>整体标签</th></tr></thead><tbody>')
        for name, model_label in rows:
            parts.append('<tr><td>'+esc(name)+'</td>'+''.join('<td>'+esc(model_label[d])+'</td>' for d in ('C', 'A', 'M'))+'<td>'+outcome(model_label['y'])+'</td></tr>')
        parts.append('</tbody></table></div>')
        for name, model_label in rows:
            parts.append('<h3>'+esc(name)+'：原始判断理由</h3><pre>'+esc(model_label['evidence'])+'</pre>')
        if key in confidence:
            c = confidence[key]
            parts.append('<h3>补充置信度复核</h3><p>采用原 Pro 第 '+str(c['selected_original_pro_pass'])+' 次结论；获选置信度分数 '+str(c['selected_confidence'])+' / 100。下列分数来自新的证据复核，不是原请求的置信度。</p>')
            for name, original_pass in zip(('candidate_a', 'candidate_b'), c['candidate_order']):
                assessment = c['confidence_assessment'][name]
                parts.append('<p>原 Pro 第 '+str(original_pass)+' 次：置信度分数 '+str(assessment['confidence'])+'</p><pre>'+esc(assessment['evidence'])+'</pre>')
        parts.append('</details></details>')
    parts.append('''<script>
const entries=Array.from(document.querySelectorAll('.entry'));
function filter(){const q=document.getElementById('search').value.toLowerCase().trim();const priority=document.getElementById('priorityOnly').checked;let n=0;for(const e of entries){e.hidden=!(e.dataset.search.includes(q)&&(!priority||e.dataset.priority==='1'));if(!e.hidden)n++;}document.getElementById('count').textContent='显示 '+n+' / 200 条';}
document.getElementById('search').addEventListener('input',filter);
document.getElementById('priorityOnly').addEventListener('change',filter);
if(location.hash){const e=document.getElementById(location.hash.slice(1));if(e)e.open=true;}
</script></body></html>''')
    target = folder/'review_packet_with_model_references_200.html'
    target.write_text('\n'.join(parts))
    assert hashlib.sha256(template_path.read_bytes()).hexdigest() == template_hash
    assert len(forms) == 200 and len(priorities) == 43 and len(pro) == 400
    print(json.dumps({'file': str(target), 'reviews': 200, 'priority': 43, 'pro_primary_labels': 400,
                      'additional_pro_labels': len(supplement), 'confidence_assessments': len(confidence),
                      'human_template_unchanged': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
